class RevenueCatConfig {
  static const String apiKeyAndroid =
      ''; // Replace with your Android RevCat API Key
  static const String apiKeyIOS = ''; // Replace with your iOS RevCat API Key
  static const String premiumEntitlementId =
      ''; // Replace with your Entitlement ID
}
